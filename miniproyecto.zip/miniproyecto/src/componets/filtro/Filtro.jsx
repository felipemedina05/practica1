
import { useState } from "react";


function Filtro() {
  const [filtro, setFiltro] = useState([]);

  return (
    <>
     
    </>
  );
}

export default Filtro;
