



function Footter() {
  

  return (
    <>
      <div className="footer">
        <footer>Hussein-Mourad @ DevChallenges.io</footer>
      </div>
    </>
  );
}

export default Footter;
